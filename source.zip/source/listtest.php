<?php
/* $current_user = wp_get_current_user();
$user_login = $current_user->user_login; */
echo "1";
echo "2";
echo "3";
$sql = 'select * from wp_users ID inner join wp_usermeta user_id on ID = user_id where meta_key = "Authority" and user_login="bko117"';
$sql2 = 'select * from wp_users ID inner join wp_usermeta user_id on ID = user_id where meta_key = "Department" and user_login="bko117"';
$result=$db->query($sql);
$result2=$db->query($sql2);
echo "4";
if($result){
	$data=$result->fetch_assoc();
}
if($result2) {
	$data2=$result2->fetch_assoc();
}
echo "5";
echo $data['meta_value'];
echo $data2['meta_value'];
echo "6";
?>
