<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>

<?php
require_once ("DBconfig.php");
$uid=$_GET['uid'];
$filenumber =$_GET['file'];
$sql = 'select file_path, file_name from wp_kboard_board_attached where content_uid="'.$uid.'" and file_key ="'.$filenumber.'"';
$result = $db->query ( $sql );
$data = $result->fetch_assoc();
$path = "/var/lib/openshift/568209652d5271f7320001d2/app-root/data/current";
$file_path = $data['file_path'];
$file = $path.$file_path;
$fileOriginalName = $data['file_name'];
if(file_exists ($file)) {
	header ("Content-Type: doesn/matter");
	header ('Content-Length:'.filesize ($file));
	header ( "Content-Disposition: attachment; filename=".$fileOriginalName); 
	header ( "Content-Transfer-Encoding: binary");
	header ( "Pragma: no-cache");
	header ( "Expires: 0"); 
	
	if (is_file ( "$file" )) {
		$fp = fopen ( "$file", "r" );
		
		if (! fpassthru ( $fp )) {
			
			fclose ( $fp );
		}
	}
} else {
	echo "<meta charset='UTF-8'><script>alert('<$fileOriginalName>�̃_�E���Ɏ��s���܂����B ); history.go(-1);</script>";
}
?>

/var/lib/openshift/568209652d5271f7320001d2/app-root/data/plugins/kboard/execute