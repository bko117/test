<?php
	$db = new mysqli('127.10.158.2:3306', 'admin6HGVi87', 'wvrlMVxye6L6', 'minais');

	if ($db->connect_error) {
		die('error');
	} 
	
	$db->set_charset('utf8');
?>