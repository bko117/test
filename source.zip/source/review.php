<?php 
require_once ("DBconfig.php");
$uid = $_GET['uid'];
$review = "";
$sql = "update wp_kboard_board_content set review='1' where uid ='$uid'";
$result=$db->query($sql);
if($result){
	if($result){
		$msg='���F�B';
        	$replaceURL = '/board';
        	?>
                			<script>
                				alert("<?php echo $msg?>");
                				location.replace("<?php echo $replaceURL?>");
                			</script>
                		<?php
                			exit;
	} else {
		$msg = '�G���[�B';
		?>
								<script>
									alert("<?php echo $msg?>");
									history.back();
								</script>
						<?php
								exit;
	}
}
?>