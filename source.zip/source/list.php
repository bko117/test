<?php
$current_user = wp_get_current_user ();
$user_login = $current_user->user_login;
echo "user_id=" . $user_login;
require_once ("DBconfig.php");
$sql = 'select * from wp_users ID inner join wp_usermeta user_id on ID = user_id where meta_key = "Authority" and user_login="' . $user_login . '"';
$result = $db->query ( $sql );
if ($result) {
	$data = $result->fetch_assoc ();
	$Authority = $data ['meta_value'];
}
echo "auth=" . $Authority;
?>
<div id="kboard-default-list">

	<!-- �ｲ��ラ尞ｼ �亨�梠 -->
	<div class="kboard-header">
		<form id="kboard-search-form" method="get"
			action="<?php echo $url->set('mod', 'list')->toString()?>">
			<?php echo $url->set('category1', '')->set('category2', '')->set('pageid', '1')->set('target', '')->set('keyword', '')->set('mod', 'list')->toInput()?>
			
			<?php if($board->use_category == 'yes'):?>
			<div class="kboard-category">
				<?php if($board->initCategory1()):?>
					<select name="category1"
					onchange="jQuery('#kboard-search-form').submit();">
					<option value=""><?php echo __('All', 'kboard')?></option>
						<?php while($board->hasNextCategory()):?>
						<option value="<?php echo $board->currentCategory()?>"
						<?php if($_GET['category1'] == $board->currentCategory()):?>
						selected="selected" <?php endif?>><?php echo $board->currentCategory()?></option>
						<?php endwhile?>
					</select>
				<?php endif?>
				
				<?php if($board->initCategory2()):?>
					<select name="category2"
					onchange="jQuery('#kboard-search-form').submit();">
					<option value=""><?php echo __('All', 'kboard')?></option>
						<?php while($board->hasNextCategory()):?>
						<option value="<?php echo $board->currentCategory()?>"
						<?php if($_GET['category2'] == $board->currentCategory()):?>
						selected="selected" <?php endif?>><?php echo $board->currentCategory()?></option>
						<?php endwhile?>
					</select>
				<?php endif?>
			</div>
			<?php endif?>
			
			<div class="kboard-search">
				<select name="target">
					<option value=""><?php echo __('All', 'kboard')?></option>
					<option value="title" <?php if($_GET['target'] == 'title'):?>
						selected="selected" <?php endif?>><?php echo __('Title', 'kboard')?></option>
					<option value="content" <?php if($_GET['target'] == 'content'):?>
						selected="selected" <?php endif?>><?php echo __('Content', 'kboard')?></option>
					<option value="member_display"
						<?php if($_GET['target'] == 'member_display'):?>
						selected="selected" <?php endif?>><?php echo __('Author', 'kboard')?></option>
				</select> <input type="text" name="keyword"
					value="<?php echo $_GET['keyword']?>">
				<button type="submit" class="kboard-default-button-small"><?php echo __('Search', 'kboard')?></button>
			</div>
		</form>
	</div>
	<!-- �ｲ��ラ尞ｼ �◎ -->

	<!-- �ｦｬ�侃孖ｸ �亨�梠 -->
	<div class="kboard-list">
		<table>
			<thead>
				<tr>
					<td class="kboard-list-uid"><?php echo __('Number', 'kboard')?></td>
					<td class="kboard-list-title"><?php echo __('Title', 'kboard')?></td>
					<td class="kboard-list-user"><?php echo __('Author', 'kboard')?></td>
					<td class="kboard-list-date"><?php echo __('Date', 'kboard')?></td>
					<td class="kboard-list-view"><?php echo __('Views', 'kboard')?></td>
					<td class="kboard-list-view">決済</td>
				</tr>
			</thead>
			<tbody>
				<?php while($content = $list->hasNextNotice()):?>
				<tr class="kboard-list-notice">
					<td class="kboard-list-uid"><?php echo __('Notice', 'kboard')?></td>
					<td class="kboard-list-title"><div class="cut_strings">
							<a
								href="<?php echo $url->set('uid', $content->uid)->set('mod', 'document')->toString()?>"><?php echo $content->title?></a>
							<?php echo $content->getCommentsCount()?>
						</div></td>
					<td class="kboard-list-user"><?php echo $content->member_display?></td>
					<td class="kboard-list-date"><?php echo date("Y.m.d", strtotime($content->date))?></td>
					<td class="kboard-list-view"><?php echo $content->view?></td>
					<td></td>
				</tr>
				<?php endwhile?>
				
				<?php while($content = $list->hasNext()):?>
				<tr>
					<td class="kboard-list-uid"><?php echo $list->index()?></td>
					<td class="kboard-list-title"><div class="cut_strings">
							<a
								href="<?php echo $url->set('uid', $content->uid)->set('mod', 'document')->toString()?>"><?php echo $content->title?>
							<?php if($content->secret):?><img
								src="<?php echo $skin_path?>/images/icon_lock.png"
								alt="<?php echo __('Secret', 'kboard')?>"><?php endif?>
							</a>
							<?php echo $content->getCommentsCount()?>
						</div></td>
					<td class="kboard-list-user"><?php echo $content->member_display?></td>
					<td class="kboard-list-date"><?php echo date("Y.m.d", strtotime($content->date))?></td>
					<td class="kboard-list-view"><?php echo $content->view?></td>
					<td><?php echo "review=====".$content->review;
					
					if ($Authority == '2') {
						
						if ($content->review == '1') {
							?>
								<img src="/wp-content/plugins/kboard/execute/stamp.png" style="width: 20px; height: 20px;"><?php echo "auth=2,review=1";?>
					<?php 
						} else { ?>
							
								<a href="/wp-content/plugins/kboard/execute/review.php?uid=<?php echo $content->uid?>"><button class="kboard-default-button-small">承認</button></a>
								<?php echo "auth=2,review=0";?>
					<?php
						}
					} else {
						
						if ($content->review == '1') { ?>
							
								<img src="/wp-content/plugins/kboard/execute/stamp.png" style="width: 20px; height: 20px;">
								<?php echo "auth=1,review=1";?>
								
				<?php 
						} else { ?>
						
							<?php echo "auth=1,review=0";?>
				<?php 
						}
					} ?>
					</td>
				</tr>
				<?php $boardBuilder->builderReply($content->uid)?>
				<?php endwhile?>
			</tbody>
		</table>
	</div>
	<!-- �ｦｬ�侃孖ｸ �◎ -->

	<!-- 寬們擽�ｧ� �亨�梠 -->
	<div class="kboard-pagination">
		<ul class="kboard-pagination-pages">
			<?php echo kboard_pagination($list->page, $list->total, $list->rpp)?>
		</ul>
	</div>
	<!-- 寬們擽�ｧ� �◎ -->
	
	<?php if($board->isWriter()):?>
	<!-- �ｲ�孖ｼ �亨�梠 -->
	<div class="kboard-control">
		<a href="<?php echo $url->set('mod', 'editor')->toString()?>"
			class="kboard-default-button-small"><?php echo __('New', 'kboard')?></a>
	</div>
	<!-- �ｲ�孖ｼ �◎ -->
	<?php endif?>
	
</div>